//package com.trable.dto;
//
//import lombok.Getter;
//import lombok.Setter;
//
//@Getter
//@Setter
//public class MemberImgDto {
//	private Long id;
//	
//	private String img_name;
//	
//	private String img_url;
//	
//	private String img_ori;
//	
//	
//}
