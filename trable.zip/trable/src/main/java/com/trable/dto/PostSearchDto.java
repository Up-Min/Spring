package com.trable.dto;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class PostSearchDto {
	
	private String searchtag;
			
}
