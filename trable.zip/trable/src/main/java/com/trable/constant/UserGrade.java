package com.trable.constant;

public enum UserGrade {
	ADMIN, ONE, TWO, THREE, FOUR
}
