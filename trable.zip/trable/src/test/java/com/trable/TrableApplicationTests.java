package com.trable;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TrableApplicationTests {

	@Test
	void contextLoads() {
	}

}
